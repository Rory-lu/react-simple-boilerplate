import React, { Component } from 'react';
import { BrowserRouter } from 'react-router-dom'
import logo from './logo.svg';
import createRoutes from './routes';

class App extends Component {
  render() {
    const { store } = this.props;
    const Routes = createRoutes(this.props.store);
    return (
      <div className="App">
        <BrowserRouter>
          <Routes />
        </BrowserRouter>
      </div>
    );
  }
}

export default App;
