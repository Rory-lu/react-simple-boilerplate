import React, { Component } from 'react';
import { Link } from "react-router-dom";

class Home extends Component {
  constructor(props) {
    super(props);
  
    this.state = {};
  }

  render() {
    return (
      <div>
        <p>This is home page</p>
        <ul>
          <li>
            <Link to='/home1'>home1</Link>
          </li>
          <li>
            <Link to='/home2'>home2</Link>
          </li>
          <li>
            <Link to='/home3'>home3</Link>
          </li>
        </ul>
      </div>
    )
  }
}

export default Home;
