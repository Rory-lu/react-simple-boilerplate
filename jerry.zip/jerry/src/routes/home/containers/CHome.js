import { connect } from 'react-redux';
import Home from '../components/Home';

const mapStateToProps = (state, ownProps) => {
  return {}
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {}
}

const CHome = connect(
  mapStateToProps,
  mapDispatchToProps
)(Home);

export default CHome;
