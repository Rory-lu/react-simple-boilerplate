import React from 'react';
import { Route, withRouter, Switch, Redirect } from 'react-router-dom';
import CLogin from './login/containers/CLogin';
import CHome from './home/containers/CHome';

const createRoutes = store => {
  return withRouter(() => {
    return (
      <Switch>
        <Route path='/login' component={CLogin} />
        <Route path='/home' component={CHome} />
      </Switch>
    )
  })
}

export default createRoutes;
