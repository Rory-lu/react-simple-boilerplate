import { connect } from 'react-redux';
import Login from '../components/Login';

const mapStateToProps = (state, ownProps) => {
  return {
    userID111: state.user.userId
  }
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
  }
}



const CLogin = connect(
  mapStateToProps,
  mapDispatchToProps
)(Login);

export default CLogin;
