import React, { Component } from 'react';

class Login extends Component {
  
  _onClickGoToHome() {
    this.props.history.push('/home');
  }

  render() {
    const { userID111 } = this.props;
    return (
      <div>
        <p>This is login page.</p>
        <button onClick={() => {this._onClickGoToHome()}}>跳转到home页面</button>
      </div>
    )
  }
}

export default Login;
